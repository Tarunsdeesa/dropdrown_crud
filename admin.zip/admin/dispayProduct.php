<?php
include('connection.php');
include('header.php');
// include('footer.php');
include('sidebar.php');

?>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Product List
            <small>advanced tables</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Data tables</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
                  <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Data Table With Full Features</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>id</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Qnt</th>
                        <!-- <th>description</th> -->
                        <th>image</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php

 $query="SELECT * FROM `product_table`";
//  print_r($query);
//  exit;
 $data = mysqli_query($conn,$query);
 $total= mysqli_num_rows($data);
//  print_r($total);
//  exit;
//  $result= mysqli_fetch_array($data);

if ($total) {
  $i=1;
  while ($result= mysqli_fetch_array($data)) {
  
?>

<tr>
  <td><?=$i?></td>
  <!-- <tr><?php  echo $result['id'] ?></tr> -->
  <td><?php echo $result['p_name'] ?></td>
  <td><?php echo $result['p_price'] ?></td>
  <!-- <td><?php echo $result['p_price'] ?></td> -->
  <td><?php echo $result['quantitie'] ?>
  <!-- image code -->
  <td><?php echo "<img src=".'uploads/'.$result['image'].'  width=100px height="100px">'; ?>
</td>
  <td>
  <a class="btn btn-Success text-light" href="deleteproduct.php?id=<?php echo $result['id']; ?> "> Delete </a>
  <button type="button" class="btn btn-secondary"> <a href="edit.php?id=<?php echo $result['id']; ?> ">Update </a></button>

    </td>
  

</tr>

   <?php
   $i++;
  }
}
?>

                      
                    </tbody>
            
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
  <?php
  include('footer.php');
  
  ?>
    
 