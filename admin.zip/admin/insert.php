<?php
include('connection.php');
if(isset($_POST['submit']))
// print_r($_POST);
// exit;
$name= $_POST['name'];
$email= $_POST['email'];
$password= $_POST['password'];
// print_r($_POST);
// exit;

$query= "INSERT INTO `user`(`name`, `email`, `password`) VALUES ('$name','$email','$password')";

// print_r($query);
// exit;
// if ($conn->query($query) === TRUE) {
//     echo"sucussfuly";
// }else {
//     echo "not";
// }
$sql = mysqli_query($conn,$query);

header('Location:login.php');
?>


<!-- ?> -->
