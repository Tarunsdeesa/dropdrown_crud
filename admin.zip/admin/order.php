<?php
include('connection.php');
include('header.php');
// include('footer.php');
include('sidebar.php');



?>

<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Data Tables
            <small>advanced tables</small>
          </h1>
          <ol style="padding: 10px;"" class="breadcrumb">
            <li><a href="dasbord.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Data tables</li>
          </ol>
        </section>
<section>
        <div class="row">
    <div class="col-xs-6">
    <div id="example1_length" class="dataTables_length">
        <label>
    <select style="margin: 10px;" size="1" name="example1_length" aria-controls="example1">
        <option value="5" selected="selected">5</option>
        <option value="25">25</option>
        <option value="50">50</option>
        <option value="100">100</option>
    </select> records per page
</label>
</div>
</div>
<div class="col-xs-6">
    <div class="dataTables_filter" id="example1_filter">
        <label style="margin: 15px;" >Search: <input type="text" aria-controls="example1"></label>
    </div>
</div>
</div>
        </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
                  <div class="box">
                <div class="box-header">
                  <h3 class="box-title">product list table</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                      <th>product_name</th>
                        <th>product_id</th>
                        <th>user_id</th>
                        <th>quantitie</th>
                        <th>date</th>
                      </tr>
                    </thead>

                    <tbody>
  
                    </tbody>
            
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
  <?php
  include('footer.php');
  
  ?>
    
 