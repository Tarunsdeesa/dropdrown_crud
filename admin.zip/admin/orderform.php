<?php
include('connection.php');


$query = "SELECT * FROM product_table"; // Replace 'dropdown_table' with your actual table name
$result = mysqli_query($conn, $query);
// print_r($query);
// $options = mysqli_fetch_array($result);
// print_r($options);
// exit;

if(isset($_POST['submit'])){
$pro_id= $_POST['dropdown'];
$quantitie= $_POST['quantitie'];
$userId = $_SESSION['user']['id'];
$currentDateTime = date('Y-m-d');
// print_r($userId);
// print_r($pro_id);
// print_r($quantitie);
// exit;
$query= "INSERT INTO `order`(`user_id`, `pro_id`, `qnt`, `date`) VALUES ('$userId ','$pro_id','$quantitie','$currentDateTime')";
 mysqli_query($conn,$query);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>

<form action="" method="post" >

<div class="mb-3">

</div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">product name</label>
    <select name="dropdown">
    <?php
 while ( $option= mysqli_fetch_array($result)) { ?>
  <option value="<?php echo  $option['id'] ?>"><?php echo  $option['p_name'] ?></option>
 
  <?php } ?>
</select>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">quantitie</label>
    <input type="text" class="form-control" id="exampleInputPassword1" name="quantitie">
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary" value="submit" name="submit">Submit</button> 
  </div>
</form>
</body>
</html>