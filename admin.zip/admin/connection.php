<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "admin";

$conn = new mysqli($server, $username, $password, $database);
session_start();

if ($conn) {
    // echo "Connected successfully";

}

else{
    echo "filed";
}


?>