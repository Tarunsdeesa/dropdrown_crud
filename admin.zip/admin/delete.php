<?php
include('connection.php');
if(isset($_GET['id']));
$id=$_GET['id'];

$sql= "DELETE FROM `user` WHERE id = $id";
$result= mysqli_query($conn,$sql);

if ($result) {

    header("Location: users.php");
 }
?>
