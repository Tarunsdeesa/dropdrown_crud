<?php
include('connection.php');
if (isset($_GET['id'])) {
 $id = $_GET['id'];
 
$query = "DELETE FROM `form` WHERE id = $id";
$data = mysqli_query($conn,$query);

if ($data) {
//    echo "delete sucsessfully";
header('location:display.php');
}

}
?>