<?php
$server = 'localhost';
$username = 'root';
$password = '';
$database = 'dropdrwn';

$conn = new mysqli($server,$username,$password,$database);

if ($conn) {
    // echo 'sucsessfully';
}




?>