<?php
include('connection.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
   $query = "SELECT * FROM `form` WHERE id = $id";
   $data = mysqli_query($conn,$query);
   $row = mysqli_fetch_assoc($data);
//    print_r($row);
//    exit;

if (isset($_POST['submit'])) {
    
$name  = $_POST['name'];
$email  = $_POST['email'];
$password  = $_POST['password'];  
$country  = $_POST['country'];
$gender  = $_POST['Gender'];
$language  = $_POST['language'];

$query = "UPDATE `form` SET `name`='$name',`email`='$email',`password`='$password',`country`='$country',`gender`='$gender',`language`='$language' WHERE id = $id";
// print_r($query);
//    exit;

$data = mysqli_query($conn,$query);
if ($data) {
    header('location:display.php');
}
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
      <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<link rel="stylesheet" href="style.css">
<script src="style.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>


</head>
<body>

<div class="container">
            <form action="" method="POST" id="registrationForm"  class="form-horizontal" role="form">
                <h2>Upadate Form</h2>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Full Name</label>
                    <div class="col-sm-9">
                        <input id="name" value = "<?php echo $row['name'];?>" name="name" type="text"  placeholder="Full Name" class="form-control" autofocus>
                        <!-- <span class="help-block">Last Name, First Name, eg.: Smith, Harry</span> -->
                    </div>
                </div>
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input id="email" value = "<?php echo $row['email'];?>" name= "email" type="email" id="email" placeholder="Email" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input value = "<?php echo $row['password'];?>" name= "password" type="password" id="password" placeholder="Password" class="form-control">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="country" class="col-sm-3 control-label">Country</label>
                    <div class="col-sm-9">
                        <select  name = "country" id="country" class="form-control">
                            <option>select country</option>
                            <option value = "<?php if ($row['country'] == 'INDIA'){echo 'selected';}?>" value="INDIA">INDIA</option>
                            <option value= " <?php if($row['country'] == 'USA'){echo 'selected';} ?>" value="USA">USA</option>
                            <option value= " <?php if($row['country'] == 'CANADA'){echo 'selected';} ?>" value="CANADA">CANADA</option>

                           <!-- value="<?php if($row['contry'] == 'india'){ echo 'selected';} ?>" -->
                        </select>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <label class="control-label col-sm-3">Gender</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input value="Female" value = " <?php if ($row['gender'] == 'Female') echo 'checked'; ?>" name = "Gender" type="radio" id="femaleRadio" value="Female">Female
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input value="Male" <?php if ($row['gender'] == 'Male') echo 'checked'; ?> name = "Gender" type="radio" id="maleRadio">Male
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input value="Unknown" <?php if ($row['gender'] == 'uncknownRadio') echo 'checked'; ?>  name = "Gender" type="radio" id="uncknownRadio">Unknown
                                </label>
                            </div>
                        </div>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <label class="control-label col-sm-3">language</label>
                    <div class="col-sm-9">
                        <div class="checkbox">
                            <label>
                        <input  <?php if ($row['language'] == 'gujarati') echo 'checked'; ?> name = "language" type="checkbox" id="calorieCheckbox" value="gujarati">gujarati
                            </label>
                        </div>
                        <div class="checkbox">
                            <label>
                                <input <?php if ($row['language'] == 'hindi') echo 'checked'; ?> name = "language" type="checkbox" id="saltCheckbox" value="hindi">hindi
                            </label>
                        </div>
                        <div class="checkbox">
                            <label>
                                <input  <?php if ($row['language'] == 'english') echo 'checked'; ?> name = "language" type="checkbox" id="saltCheckbox" value="english">english
                            </label>
                        </div>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox">I accept <a href="#">terms</a>
                            </label>
                        </div>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button name="submit" type="submit" class="btn btn-primary btn-block">upadate</button>
                    </div>
                </div>
            </form> <!-- /form -->
        </div> <!-- ./container -->
</body>
</html>