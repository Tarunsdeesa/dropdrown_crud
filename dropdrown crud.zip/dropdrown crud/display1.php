<?php

include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <style>
            .row {
      margin-bottom: 20px;
    }
       
    .button.button-small {
      height: 30px;
      line-height: 30px;
      padding: 0px 10px;
    }
    
    td input[type=text],
    td select {
      width: 100%;
      height: 30px;
      margin: 0;
      padding: 2px 8px;
    }
    
    th:last-child {
      text-align: right;
    }
    
    td:last-child {
      text-align: right;
    }
    
    td:last-child .button {
      width: 30px;
      height: 30px;
      text-align: center;
      padding: 0px;
      margin-bottom: 0px;
      margin-right: 5px;
      background-color: #FFF;
    }
    
    td:last-child .button .fa {
      line-height: 30px;
      width: 30px;
    }
    </style>
</head>
<body>
<div class="container">

<div class="row">
  <div class="col-md-12">
    <br>
    <button class="btn btn-default pull-right add-row"><i class="fa fa-plus"></i>&nbsp;&nbsp; Add Row</button>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    <table class="table table-bordered" id="editableTable">
      <thead>
        <tr>
          <th>id</th>
          <th>name</th>
          <th>email</th>
          <th>password</th>
          <th>country</th>
          <th>gender</th>
          <th>language</th>
          <th>action</th>
        </tr>
      </thead>
      <tbody>
        <?php
 $query = "SELECT * FROM `form`";
 $data = mysqli_query($conn,$query);
 $total = mysqli_num_rows($data);
 $row = mysqli_fetch_array($data);
 if ($total > 0) {
    while ($row = mysqli_fetch_array($data)) {
    ?>
    <tr>
<td><?php echo $row['id'];?></td>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['password'];?></td>
<td><?php echo $row['country'];?></td>
<td><?php echo $row['gender'];?></td>
<td><?php echo $row['language'];?></td>
<td>
            <a href="delete.php?id= <?php echo $row['id'];?>" class="button button-small edit" title="Edit">
              <i class="fa fa-pencil"></i>
              </a>
            
            <a class="button button-small edit" title="Delete">
              <i class="fa fa-trash"></i>
            </a>
          </td>


    </tr>
      </tbody>
      <?php
    }
 }
 ?>
    </table>
  </div>
</div>
</div>
</body>
</html>