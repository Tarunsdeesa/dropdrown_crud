<?php

include('connection.php');

$name  = $_POST['name'];
$email  = $_POST['email'];
$password  = $_POST['password'];  
$country  = $_POST['country'];
$gender  = $_POST['Gender'];
$language  = $_POST['language'];



$query = "INSERT INTO `form`(`name`, `email`, `password`, `country`, `gender`, `language`) VALUES ('$name','$email','$password','$country','$gender','$language')";

if ($conn->query($query) === true) {

    // echo "insert sucsessfullyy";
    header('location:display.php');
}







?>