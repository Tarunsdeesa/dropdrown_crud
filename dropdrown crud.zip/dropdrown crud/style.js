$(document).ready(function() {
    $('#registrationForm').validate({
      rules: {
        name: {
          required: true,

        },
        email: {
          required: true,
          email: true,
        },
        password: {
          required: true,
          minlength: 6
        },
        country: {
            required: true,
            // minlength: 6
          }
      },
      messages: {
        name: {
          required: 'Please enter a name.',
        },
        email: {
          required: 'Please enter an email.',
          email: 'Please enter a valid email address.'
        },
        password: {
          required: 'Please enter a password.',
          minlength: 'Password should have at least 6 characters.'
        },
        country: {
            required: 'Please enter a country.',
            // minlength: 'Password should have at least 6 characters.'
          }
      },
      submitHandler: function(form) {
        // Form submission logic goes here
        form.submit();
      }
    });
  });
  