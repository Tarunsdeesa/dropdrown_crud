<?php

include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Bootstrap Simple Data Table</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style1.css">
<script>
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});
</script>
</head>
<body>
<div class="container-xl">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Customer <b>Details</b></h2></div>
                    <div class="col-sm-4">
                        <div class="search-box">
                            <!-- <i class="material-icons">&#xE8B6;</i> -->
                            <a href="register.php" type="submit" class="btn btn-secondary">add user</a>

                            
                        </div>
                    </div>
                </div>
            </div>
            <table class="table table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        
                        <th>id<i class="fa fa-sort"></i></th>
                        <th>name</th>
                        <th>email <i class="fa fa-sort"></i></th>
                        <th>password</th>
                        <th>country</th>
                        <th>gender</th>
                        <th>language</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
               <?php
           $query = "SELECT * FROM `form`";
           $data = mysqli_query($conn,$query);
        //    print_r($data);
        //    exit;
        $total = mysqli_num_rows($data);
        // $row = mysqli_fetch_array($data);
        if ($total > 0) {
            while ($row = mysqli_fetch_array($data)) {
                ?>
                <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['password'];?></td>
                    <td><?php echo $row['country'];?></td>
                    <td><?php echo $row['gender'];?></td>
                    <td><?php echo $row['language'];?></td>
        
                        <td>
                            <a href="#" class="view" title="View"><i class="material-icons">&#xE417;</i></a>
                            <a href="edit.php?id= <?php echo $row['id'];?>" class="edit" title="Edit"><i class="material-icons">&#xE254;</i></a>
                            <a href="delete.php?id= <?php echo $row['id'];?>" class="delete" title="Delete"><i class="material-icons">&#xE872;</i></a>
                        </td>
                        </tr>
               <?php
           }
        }
         ?>
                </tbody>
            </table>
            <div class="clearfix">
                <div class="hint-text">Showing <b>5</b> out of <b>25</b> entries</div>
                <ul class="pagination">
                    <li class="page-item disabled"><a href="#"><i class="fa fa-angle-double-left"></i></a></li>
                    <li class="page-item"><a href="#" class="page-link">1</a></li>
                    <li class="page-item"><a href="#" class="page-link">2</a></li>
                    <li class="page-item active"><a href="#" class="page-link">3</a></li>
                    <li class="page-item"><a href="#" class="page-link">4</a></li>
                    <li class="page-item"><a href="#" class="page-link">5</a></li>
                    <li class="page-item"><a href="#" class="page-link"><i class="fa fa-angle-double-right"></i></a></li>
                </ul>
            </div>
        </div>
    </div>  
</div>   
</body>
</html>



